<form action="" method="post" enctype="multipart/form-data">
    <label for='post'>Add new module here:</label>
    <textarea name="module" rows="3" cols="40"></textarea>
    <input type="submit" name="submit" value="Add">
</form>