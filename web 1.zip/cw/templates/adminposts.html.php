<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Posts</title>
</head>
<body>
<?php if (!empty($posts)): ?>
    <p><?=$totalPosts?> posts have been uploaded to the Internet Post Web.</p>
    <?php foreach ($posts as $post): ?>
        <blockquote>
            <div class="post-id">
                <strong>Section: </strong><?= htmlspecialchars($post['id'], ENT_QUOTES, 'UTF-8') ?>
            </div>
            <div class="post-content">
                <p><?= htmlspecialchars($post['post'], ENT_QUOTES, 'UTF-8') ?></p>
            </div>
            <div class="post-module">
                    <strong>Module:</strong> <span class="module-name"><?= htmlspecialchars($post['moduleName'], ENT_QUOTES, 'UTF-8') ?></span>
            </div>

            <div class="author-info">
                <p>By <strong><a href="mailto:<?= htmlspecialchars($post['email'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($post['username'], ENT_QUOTES, 'UTF-8'); ?></a></strong></p>
            </div>

            <!-- Hiển thị hình ảnh đã upload, không có nút chỉnh sửa -->
            <?php if ($post['image']): ?>
                <div class="post-image">
                    <img src="../user/uploads/<?= htmlspecialchars($post['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="Post image" />
                </div>
            <?php endif; ?>

            <!-- Chỉ cho phép xóa bài viết, không cho phép chỉnh sửa hình ảnh -->
            <div class="form-group">
                <form action="deletepost.php" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?=$post['id']?>">
                    <input type="submit" value="Delete">
                </form>
            </div>
        </blockquote>
    <?php endforeach; ?>
<?php else: ?>
    <p>No post found.</p>
<?php endif; ?>

</body>
</html>
