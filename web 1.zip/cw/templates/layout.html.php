<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="web.css">
    <title><?=$title?></title>
</head>
<body>
    <header><h1>Internet Post Web</h1></header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postuser.php">Post List</a></li>
            <li><a href="login/Login.html.php">Login</a></li> 
            <li><a href="login/register.html.php">Sign up</a></li> 
            
               
        </ul>
    </nav>
    <main>
       <?=$output?>
    </main>
    <footer>&copy; IJDB 2024</footer>

</body>
</html>