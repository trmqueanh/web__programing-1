<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../web.css">
    <title><?=$title?></title>
</head>
<body>
    <header id="user">
        <h1 >Internet Post Web<br/></h1>
        <h2 id="user">User Page<br/></h2></header>
    <nav>
        <ul>
            <li><a href="../user/posts.php">Post List</a></li>
            <li><a href="../user/addpost.php">Ask Question</a></li>
            <li><a href="../user/addfeedback.php">Feedback</a></li>
            <li><a href="../login/Logout.php">Logout</a></li>
               
        </ul>
    </nav>
    <main>
       <?=$output?>
    </main>
    <footer>&copy; IJDB 2024</footer>

</body>
</html>