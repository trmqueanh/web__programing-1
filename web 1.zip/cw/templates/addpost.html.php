<form action="" method="post" enctype="multipart/form-data">
    <label for='post'>Type your new post here:</label>
    <textarea name="post" rows="3" cols="40"></textarea>

    <select name="users">
        <option value="">select your name</option>
        <?php foreach ($users as $user): ?>
            <option value="<?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <select name="modules">
        <option value="">select one module</option>
        <?php foreach ($modules as $module): ?>
            <option value="<?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="image">Upload an image:</label>
    <input type="file" name="image" accept="image/*">

    <input type="submit" name="submit" value="Add">
</form>
