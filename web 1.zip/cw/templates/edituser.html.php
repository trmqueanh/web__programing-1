<form action="" method="post">
    <input type="hidden" name="userid" value="<?=$user['id'];?>">
    <label for="user">Edit your username here:</label>
    <textarea name="user" rows="3" cols="40"><?=$user['username']?></textarea>
    <input type="submit" name="submit" value="Save">
</form>

