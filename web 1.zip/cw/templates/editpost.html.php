        <form action="" method="post">
        <input type="hidden" name="postid" value="<?= htmlspecialchars($post['id']) ?>">

        <label for="post">Edit your post:</label>
        <textarea name="post" id="post" required><?= htmlspecialchars($post['post']) ?></textarea>
        
        
        <label for="user">Select User:</label>
        <select name="user">
            <?php foreach ($users as $user): ?>
                <option value="<?= $user['id'] ?>" <?= $user['id'] == $post['userid'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($user['username']) ?>
                </option>
            <?php endforeach; ?>
        </select>
            

        <label for="module">Select Module:</label>
        <select name="module">
            <?php foreach ($modules as $module): ?>
                <option value="<?= $module['id'] ?>" <?= $module['id'] == $post['moduleid'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($module['moduleName']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <input type="submit" name="submit" value="Save">
    </form>
</body>
</html>