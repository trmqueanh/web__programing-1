<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../web.css">
    <title><?=$title?></title>
</head>
<body>
    <header id="admin">
        <h1>Internet Post Web<br/></h1>
        <h2 id="admin"> Admin Page<br/></h2></header>
    <nav>
        <ul>
            <li><a href="../admin/posts.php">Post List</a></li>
            <li><a href="users.php">User List</a></li>
            <li><a href="modules.php">Module List</a></li>
            <li><a href="../admin/addmodule.php">Add Module</a></li>
            <li><a href="feedback.php">Feedback</a></li> 
            <li><a href="../login/Logout.php">Logout</a></li>  
        </ul>
    </nav>
    <main>
       <?=$output?>
    </main>
    <footer>&copy; IJDB 2024</footer>

</body>
</html>