<form action="" method="post">
    <input type="hidden" name="userid" value="<?=$module['id'];?>">
    <label for="module">Edit your module name here:</label>
    <textarea name="module" rows="3" cols="40"><?=$module['moduleName']?></textarea> <!-- Hiển thị tên module -->
    <input type="submit" name="submit" value="Save">
</form>
