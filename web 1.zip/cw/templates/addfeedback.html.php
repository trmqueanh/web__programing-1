<form action="" method="post" enctype="multipart/form-data">
    <label for="post">Type your feedback here:</label>
    <textarea name="post" rows="3" cols="40" required></textarea>

    <select name="users" required>
        <option value="">Select your name</option>
        <?php foreach ($users as $user): ?>
            <option value="<?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <input type="submit" name="submit" value="Submit Feedback">
</form>
