<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Feedback</title>
</head>
<body>
    <?php if (isset($error)): ?>
        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php else: ?>
        <?php if (!empty($feedbacks)): ?>
            <p><?=$totalFeedbacks?> Feedback have posted in to the Internet Post Web.</p>
            <?php foreach ($feedbacks as $feedback): ?>
                <blockquote class="feedback-block">
                    <div class="feedback-item">
                        <strong>ID:</strong> <?= htmlspecialchars($feedback['id'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                    <div class="feedback-item">
                        <strong>Username:</strong> <?= htmlspecialchars($feedback['username'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                    <div class="feedback-item">
                        <strong>Message:</strong> <?= htmlspecialchars($feedback['content'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                    <div class="feedback-item">
                        <strong>Created At:</strong> <?= htmlspecialchars($feedback['created_at'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                    <div class="feedback-item">
                        <strong>Status:</strong> <?= htmlspecialchars($feedback['status'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                </blockquote>



            <?php endforeach; ?>
        <?php else: ?>
            <p>No feedback found.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>