<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Module</title>
</head>
<body>
    <?php if (isset($error)): ?>
        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php else: ?>
        <?php if (!empty($modules)): ?>
            <p><?=$totalModules?> modules have posted in to the Internet Post Web.</p>
            <?php foreach ($modules as $module): ?>
                <blockquote>
                            <div class="module-info">
                <div class="module-item">
                    <strong>ID:</strong> <?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8') ?>
                </div>
                <div class="module-item">
                    <strong>Module Name:</strong> <?= htmlspecialchars($module['moduleName'], ENT_QUOTES, 'UTF-8') ?>
                </div>
            </div>

                    
                    <div class="form-group">
                <form action="editmodule.php" method="get" style="display:inline;">
                    <input type="hidden" name="id" value="<?=$module['id']?>">
                    <input type="submit" value="Edit">
                </form>
               
                <form action="deletemodule.php" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?=$module['id']?>">
                    <input type="submit" value="Delete">
                </form>
            </div> 
                    
                </blockquote>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No module found.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>