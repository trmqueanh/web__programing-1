<h2>Welcome to the Internet Post Web</h2>
<p>Please click on the "Post List" to view the posts without needing to log in to an account.</p>