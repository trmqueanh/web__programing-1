<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of User</title>
</head>
<body>
    <?php if (isset($error)): ?>
        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php else: ?>
        <?php if (!empty($users)): ?>
            <p><?=$totalUsers?> users have logged in to the Internet Post Web.</p>
            <?php foreach ($users as $user): ?>
                <blockquote>
                                <div class="user-info">
                    <div class="user-item">
                        <strong>ID:</strong> <?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                    <div class="user-item">
                        <strong>Username:</strong> <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                    <div class="user-item">
                        <strong>Email:</strong> <?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?>
                    </div>
                </div>

                    <div class="form-group">
                <form action="edituser.php" method="get" style="display:inline;">
                    <input type="hidden" name="id" value="<?=$user['id']?>">
                    <input type="submit" value="Edit">
                </form>
              
                <form action="deleteuser.php" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?=$user['id']?>">
                    <input type="submit" value="Delete">
                </form>
            </div> 
                    
                </blockquote>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No user found.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html