<?php
session_start();
try {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Lấy email và password từ form
        $email = trim($_POST["email"]);
        $password = trim($_POST["password"]);

        // Kiểm tra trong bảng admin trước
        $queryAdmin = 'SELECT email, password FROM admin WHERE email = :email';
        $statementAdmin = $pdo->prepare($queryAdmin);
        $statementAdmin->execute(['email' => $email]);
        $admin = $statementAdmin->fetch();

        // Nếu tồn tại trong bảng admin và mật khẩu đúng
        if ($admin && $password === $admin['password']) {
            $_SESSION["Authorised"] = "Admin";  // Cập nhật session thành Admin
            $_SESSION["Email"] = $email;
            header("Location: ../admin/posts.php");
            exit;
        }

        // Kiểm tra trong bảng user nếu không phải admin
        $queryUser = 'SELECT email, password FROM user WHERE email = :email';
        $statementUser = $pdo->prepare($queryUser);
        $statementUser->execute(['email' => $email]);
        $user = $statementUser->fetch();

        // Nếu tồn tại trong bảng user và mật khẩu đúng
        if ($user && $password === $user['password']) {
            $_SESSION["Authorised"] = "User";  // Cập nhật session thành User
            $_SESSION["Email"] = $email;
            header("Location: ../user/posts.php");
            exit;
        }

        // Nếu không tìm thấy trong cả admin và user
        header("Location: Wrongpassword.php");
        exit;
    }
} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}
?>
