<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../login.css">
    <title>Login Page</title>
</head>
<body>
    <div class="glass-container">
        <div class="login-box">
            <h2>Login</h2>
            <form action="validate.php" method="POST">

            <input type="text" id="email" name="email" required placeholder="Email">
            <input type="password" id="password" name="password" required placeholder="Password">
            
            <div class="options">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">Remember me</label>
               
</div>
<button type="submit">Login</button>
</form>
</div>
</div>
</body>
</html>
