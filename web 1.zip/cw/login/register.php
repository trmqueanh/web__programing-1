<?php

// Hàm thêm người dùng mới
function registerUser($pdo, $username, $email, $password) {
    // Truy vấn SQL để thêm người dùng vào cơ sở dữ liệu
    $query = 'INSERT INTO user (username, email, password) 
    VALUES (:username, :email, :password)';
    $parameters = [
        ':username' => $username,
        ':email' => $email,
        ':password' => $password 
    ];

    // Thực thi truy vấn
    $stmt = $pdo->prepare($query);
    $stmt->execute($parameters);
}

// Kiểm tra nếu form đã được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Bao gồm kết nối cơ sở dữ liệu và các hàm hỗ trợ
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunction.php';

        // Lấy dữ liệu từ form đăng ký
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        // Kiểm tra các trường không được bỏ trống
        if (empty($username) || empty($email) || empty($password)) {
            throw new Exception('All fields are required.');
        }

        // Thêm người dùng mới vào cơ sở dữ liệu
        registerUser($pdo, $username, $email, $password);

        // Sau khi đăng ký thành công, chuyển hướng đến trang đăng nhập
        header('Location: Login.html.php');
        exit();
    } catch (PDOException $e) {
        // Xử lý lỗi kết nối cơ sở dữ liệu
        $error = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        // Xử lý các lỗi khác
        $error = $e->getMessage();
    }
}
?>

