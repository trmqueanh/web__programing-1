<?php
session_start();
if (!isset($_SESSION["Authorised"]) || ($_SESSION["Authorised"] !== "Admin" && $_SESSION["Authorised"] !== "User")) {
    header("Location: ../login/Notauthorised.php");
    exit; // Dừng lại ngay sau khi chuyển hướng
}
?>
