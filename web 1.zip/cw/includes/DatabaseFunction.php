<?php
function totalPosts($pdo){
    $query = $pdo->prepare('SELECT COUNT(*) FROM post');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}

function totalUsers($pdo){
    $query = $pdo->prepare('SELECT COUNT(*) FROM user');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}
function totalModules($pdo) {
    $query = $pdo->prepare('SELECT COUNT(*) FROM module');
    $query->execute();
    $row = $query->fetch();
    return $row[0];

}
function totalFeedbacks($pdo) {
    $query = $pdo->prepare('SELECT COUNT(*) FROM feedback');
    $query->execute();
    $row = $query->fetch();
    return $row[0];
}

function query($pdo, $sql, $parameters = []) {
    $query = $pdo->prepare($sql);
    $query->execute($parameters);
    return $query;
}