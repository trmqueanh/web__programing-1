<?php
require "../login/Check.php";
try {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';

    $feedbacks = allFeedbacks($pdo);
    $title = 'Feedback List';
    $totalFeedbacks = totalFeedbacks($pdo);
    ob_start();
    include '../templates/feedback.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage();
}

function allFeedbacks($pdo) {
    $feedbacks = query($pdo, 'SELECT feedback.id, feedback.content, feedback.created_at, feedback.status, user.username FROM feedback
    JOIN user ON feedback.user_id = user.id');
    return $feedbacks->fetchAll();
}

include '../templates/admin_layout.html.php';
?>