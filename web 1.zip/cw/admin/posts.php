<?php
require "../login/Check.php";
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';
    
    $posts = allPosts($pdo);
    $title = 'Post List';
    $totalPosts = totalPosts($pdo);
    ob_start();
    include '../templates/adminposts.html.php';
    $output = ob_get_clean(); 
}catch (PDOException $e) {
    $title = 'An error has occured';
    $output= 'Database error: ' . $e->getMessage();
    
    
}
function allPosts($pdo) {
    $posts = query($pdo, 'SELECT post.id, post.post, username, email, moduleName, image FROM post
    INNER JOIN user ON userid = user.id
    INNER JOIN module ON moduleid = module.id');
    return $posts->fetchAll();
}


include '../templates/admin_layout.html.php';
?>