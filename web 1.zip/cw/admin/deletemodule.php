<?php 
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';
    deleteModules($pdo, $_POST ['id']);
    header('location: modules.php');
}catch(PDOException $e){
    $title = 'An error has occurred';
    $output = 'Unable to connect to delete post:: ' . $e->getMessage();
}
function deleteModules($pdo, $id){
    $parameters = [':id'=> $id];
    query($pdo, 'DELETE FROM module WHERE id = :id', $parameters);
}
include '../templates/admin_layout.html.php';