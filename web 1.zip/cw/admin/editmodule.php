<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunction.php';

try {
    if (isset($_POST['module'])) { // Kiểm tra xem người dùng đã gửi dữ liệu
        updateModule($pdo, $_POST['userid'], $_POST['module']); // Lưu dữ liệu vào bảng 'module'
        header('Location: modules.php'); // Chuyển hướng sau khi lưu
        exit(); // Dừng script để tránh tiếp tục chạy
    } else {
        $module = getModule($pdo, $_GET['id']); // Lấy thông tin module để hiển thị
        $title = 'Edit module';

        ob_start();
        include '../templates/editmodule.html.php'; // Bao gồm form chỉnh sửa module
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Error editing module: ' . $e->getMessage();
}

// Cập nhật module
function updateModule($pdo, $userid, $moduleName) {
    // Cập nhật dữ liệu vào bảng 'module' với trường 'moduleName' và 'id'
    $query = 'UPDATE module SET moduleName = :moduleName WHERE id = :id'; // Cập nhật dữ liệu
    $parameters = [':moduleName' => $moduleName, ':id' => $userid]; // Truyền tham số đúng
    query($pdo, $query, $parameters); // Gọi hàm truy vấn
}

// Lấy thông tin module từ CSDL
function getModule($pdo, $id) {
    // Truy vấn lấy dữ liệu từ bảng 'module'
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM module WHERE id = :id', $parameters); // Lấy dữ liệu module
    return $query->fetch();
}

include '../templates/admin_layout.html.php'; // Bao gồm layout
