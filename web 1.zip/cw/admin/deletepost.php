<?php 
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';
    deletePosts($pdo, $_POST ['id']);
    header('location: posts.php');
}catch(PDOException $e){
    $title = 'An error has occurred';
    $output = 'Unable to connect to delete post:: ' . $e->getMessage();
}
function deletePosts($pdo, $id){
    $parameters = [':id'=> $id];
    query($pdo, 'DELETE FROM post WHERE id = :id', $parameters);
}
include '../templates/admin_layout.html.php';