<?php

// Hàm thêm module
function insertModule($pdo, $moduleName) {
    $query = 'INSERT INTO module (moduleName) VALUES (:moduleName)';
    $parameters = [':moduleName' => $moduleName];
    query($pdo, $query, $parameters);
}

if (isset($_POST['module'])) {
    try {
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunction.php';

        // Lấy tên module từ form
        $moduleName = trim($_POST['module']);  // loại bỏ khoảng trắng

        // Kiểm tra tên module không rỗng
        if (!empty($moduleName)) {
            insertModule($pdo, $moduleName);
            $successMessage = 'Module added successfully!'; // Thông báo thành công
        } else {
            throw new Exception('Module name cannot be empty.');
        }
    } catch (PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $title = 'An error has occurred';
        $output = $e->getMessage();
    }
} else {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';
    $title = 'Add a new module';
}

// Hiển thị form thêm module
ob_start();
include '../templates/addmodule.html.php'; // Template form thêm module
if (isset($successMessage)) {
    echo '<p style="color: green;">' . htmlspecialchars($successMessage) . '</p>'; // Hiển thị thông báo
}
$output = ob_get_clean();

include '../templates/admin_layout.html.php'; // Giao diện chung
?>
