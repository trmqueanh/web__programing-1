<?php 
try{
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';
    deleteUsers($pdo, $_POST ['id']);
    header('location: users.php');
}catch(PDOException $e){
    $title = 'An error has occurred';
    $output = 'Unable to connect to delete user:: ' . $e->getMessage();
}
function deleteUsers($pdo, $id){
    $parameters = [':id'=> $id];
    query($pdo, 'DELETE FROM user WHERE id = :id', $parameters);
}
include '../templates/admin_layout.html.php';