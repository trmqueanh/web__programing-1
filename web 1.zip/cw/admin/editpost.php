<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunction.php';
try{
    if(isset($_POST['post'])){
        updatePost($pdo, $_POST['postid'], $_POST['post']);
        header('location: posts.php');
    }else{
       $post = getPost($pdo, $_GET['id']);
        $title = 'Edit post';

        ob_start();
        include '../templates/editpost.html.php';
        $output = ob_get_clean();
    }
}catch (PDOException $e){
    $title = 'An error has occurred';
    $output = 'Error editing post: ' . $e->getMessage();
}
function updatePost($pdo, $postid, $post){
    $query = 'UPDATE post SET post = :post WHERE id = :id';
    $parameters = [':post' => $post, ':id' => $postid];
    query($pdo, $query, $parameters);
}
function getPost($pdo, $id){
    $parameters = [':id' => $id];
    $query = query ($pdo, 'SELECT *FROM post WHERE id = :id', $parameters);
    return $query->fetch();
}
include '../templates/admin_layout.html.php';