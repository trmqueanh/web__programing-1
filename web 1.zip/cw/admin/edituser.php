<?php 
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunction.php';

try {
    if (isset($_POST['user'])) { // Kiểm tra xem người dùng đã gửi dữ liệu
        updateUser($pdo, $_POST['userid'], $_POST['user']); // Lưu dữ liệu
        header('Location: users.php'); // Chuyển hướng sau khi lưu
        exit(); // Dừng script để tránh tiếp tục chạy
    } else {
        $user = getUser($pdo, $_GET['id']); // Lấy thông tin người dùng để hiển thị
        $title = 'Edit user';

        ob_start();
        include '../templates/edituser.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Error editing user: ' . $e->getMessage();
}

function updateUser($pdo, $userid, $user) {
    $query = 'UPDATE user SET username = :username WHERE id = :id'; // Cập nhật dữ liệu
    $parameters = [':username' => $user, ':id' => $userid]; // Truyền tham số đúng
    query($pdo, $query, $parameters); // Gọi hàm truy vấn
}

function getUser($pdo, $id) {
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM user WHERE id = :id', $parameters); // Lấy dữ liệu người dùng
    return $query->fetch();
}

include '../templates/admin_layout.html.php'; // Bao gồm layout
