<?php
require "../login/Check.php";
try {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';

    $users = allUsers($pdo);
    $title = 'User List';
    $totalUsers = totalUsers($pdo);
    ob_start();
    include '../templates/user.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage();
}

function allUsers($pdo) {
    $users = query($pdo, 'SELECT id, username, email FROM user');
    return $users->fetchAll();
}
include '../templates/admin_layout.html.php';
?>
