<?php

// Hàm thêm feedback vào cơ sở dữ liệu, bao gồm cả username
function insertFeedback($pdo, $userId, $content, $username) {
    $query = 'INSERT INTO feedback (user_id, content, username) 
    VALUES (:user_id, :content, :username)';
    $parameters = [
        ':user_id' => $userId,
        ':content' => $content,
        ':username' => $username
    ];
    query($pdo, $query, $parameters);
}
$title = 'Add a new feedback';

if (isset($_POST['submit'])) {
    try {
        include '../includes/DatabaseConnection.php'; // Kết nối DB
        include '../includes/DatabaseFunction.php'; // Các hàm xử lý DB

        // Lấy thông tin từ form
        $content = trim($_POST['post']); // Nội dung feedback
        $userId = $_POST['users']; // ID người dùng được chọn

        // Lấy username từ bảng user
        $query = "SELECT username FROM user WHERE id = $userId";
        $statement = $pdo->query($query);
        $user = $statement->fetch(PDO::FETCH_ASSOC);
        $username = $user['username'];


        // Kiểm tra dữ liệu
        if (!empty($content) && !empty($userId) && !empty($username)) {
            // Thêm feedback vào cơ sở dữ liệu
            insertFeedback($pdo, $userId, $content, $username);
            $successMessage = 'Your feedback has been submitted successfully!';
        } else {
            throw new Exception('Please provide valid feedback and select a user.');
        }
    } catch (PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $title = 'An error has occurred';
        $output = $e->getMessage();
    }
}

// Lấy danh sách người dùng từ cơ sở dữ liệu
try {
    include '../includes/DatabaseConnection.php'; // Kết nối DB
    $query = 'SELECT id, username FROM user'; // Truy vấn lấy người dùng
    $statement = $pdo->prepare($query);
    $statement->execute();
    $users = $statement->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $title = 'Error';
    $output = 'Database error: ' . $e->getMessage();
}

ob_start();
include '../templates/addfeedback.html.php'; // Giao diện form nhập feedback
if (isset($successMessage)) {
    echo '<p style="color: green;">' . htmlspecialchars($successMessage) . '</p>'; // Thông báo thành công
}
$output = ob_get_clean();

include '../templates/user_layout.html.php'; // Layout chung
?>
