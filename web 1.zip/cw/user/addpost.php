<?php
//chen
function insertPost($pdo, $post, $userid, $moduleid, $imageName) {
    $query = 'INSERT INTO post (post, postdate, userid, moduleid, image) 
              VALUES (:post, CURDATE(), :userid, :moduleid, :image)';
    $parameters = [
        ':post' => $post, 
        ':userid' => $userid, 
        ':moduleid' => $moduleid, 
        ':image' => $imageName
    ];
    query($pdo, $query, $parameters);
}

if (isset($_POST['post'])) {    // test form data yet
    try {
        include '../includes/DatabaseConnection.php';
        include '../includes/DatabaseFunction.php';

        // upload image 
        if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {  // test error
            $imageTmpName = $_FILES['image']['tmp_name'];   // name tạm
            $imageName = basename($_FILES['image']['name']);      //basename
            $imagePath = '../user/uploads/' . $imageName;     //folder image

            // Di chuyển ảnh đến thư mục uploads
            if (move_uploaded_file($imageTmpName, $imagePath)) {
                insertPost($pdo, $_POST['post'], $_POST['users'], $_POST['modules'], $imageName);
            } else {
                throw new Exception('Failed to upload image.');
            }
        } else {
            insertPost($pdo, $_POST['post'], $_POST['users'], $_POST['modules'], '');
        }

        header('location: posts.php');
    } catch (PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $title = 'An error has occurred';
        $output = $e->getMessage();
    }
} else {   //no data
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';
    $title = 'Add a new post';
    $users = allUsers($pdo);   
    $modules = allModules($pdo);
    ob_start();
    include '../templates/addpost.html.php';
    $output = ob_get_clean();
}

function allUsers($pdo) {
    $users = query($pdo, 'SELECT * FROM user');
    return $users->fetchAll();
}

function allModules($pdo) {
    $modules = query($pdo, 'SELECT * FROM module');
    return $modules->fetchAll();
}

include '../templates/user_layout.html.php';
?>
