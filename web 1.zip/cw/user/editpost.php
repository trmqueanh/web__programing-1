<?php
include '../includes/DatabaseConnection.php';
include '../includes/DatabaseFunction.php';

try {
    if (isset($_POST['post'])) {
        // Update the post with user and module changes
        updatePost($pdo, $_POST['postid'], $_POST['post'], $_POST['user'], $_POST['module']);
        header('location: posts.php');
    } else {
        // Fetch the post data for editing
        $post = getPost($pdo, $_GET['id']);
        $users = allUsers($pdo); // Fetch all users
        $modules = allModules($pdo); // Fetch all modules
        $title = 'Edit post';

        ob_start();
        include '../templates/editpost.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Error editing post: ' . $e->getMessage();
}

// Update post in the database
function updatePost($pdo, $postid, $post, $userId, $moduleId) {
    $query = 'UPDATE post SET post = :post, userid = :userid, moduleid = :moduleid WHERE id = :id';
    $parameters = [
        ':post' => $post,
        ':userid' => $userId,
        ':moduleid' => $moduleId,
        ':id' => $postid
    ];
    query($pdo, $query, $parameters);
}

// Fetch a specific post by ID
function getPost($pdo, $id) {
    $parameters = [':id' => $id];
    $query = query($pdo, 'SELECT * FROM post WHERE id = :id', $parameters);
    return $query->fetch();
}

// Fetch all users
function allUsers($pdo) {
    $users = query($pdo, 'SELECT * FROM user');
    return $users->fetchAll();
}

// Fetch all modules
function allModules($pdo) {
    $modules = query($pdo, 'SELECT * FROM module');
    return $modules->fetchAll();
}

include '../templates/user_layout.html.php';
