<?php

try {
    include '../includes/DatabaseConnection.php';
    include '../includes/DatabaseFunction.php';

    // Lấy tất cả bài viết từ cơ sở dữ liệu
    $posts = allPosts($pdo);
    $title = 'Post List';
    $totalPosts = totalPosts($pdo);

    // Tạo nội dung HTML tạm thời
    ob_start();
    include '../templates/posts.html.php';
    $output = ob_get_clean();
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Database error: ' . $e->getMessage();
}

// Hàm lấy tất cả bài viết từ cơ sở dữ liệu
function allPosts($pdo) {
    $posts = query($pdo, 'SELECT post.id, post.post, username, email, moduleName, image FROM post
    INNER JOIN user ON userid = user.id
    INNER JOIN module ON moduleid = module.id');
    return $posts->fetchAll();
}

include '../templates/user_layout.html.php';
?>
