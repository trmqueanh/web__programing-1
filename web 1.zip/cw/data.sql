-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2024 at 10:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `created_at`) VALUES
(1, 'trmqueanh@gmail.com', 'toilaadmin', '2024-12-06 11:27:46');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `username`, `content`, `created_at`, `status`) VALUES
(11, 1, 'john_doe', 'This is a great system. Keep improving!', '2024-12-09 17:45:44', 'Pending'),
(12, 2, 'jane_smith', 'The interface can be improved.', '2024-12-09 17:45:44', 'Pending'),
(13, 3, 'michael_brown', 'Very user-friendly, but needs more features.', '2024-12-09 17:45:44', 'Pending'),
(14, 4, 'emily_white', 'I had a few bugs when using the app.', '2024-12-09 17:45:44', 'Pending'),
(15, 5, 'william_jones', 'Good, but could be faster.', '2024-12-09 17:45:44', 'Pending'),
(16, 6, 'olivia_davis', 'It works perfectly, no issues at all!', '2024-12-09 17:45:44', 'Pending'),
(17, 7, 'daniel_miller', 'Could use better mobile responsiveness.', '2024-12-09 17:45:44', 'Pending'),
(18, 18, 'queanh', 'Really liked the design, smooth experience.', '2024-12-09 17:45:44', 'Pending'),
(19, 1, 'john_doe', 'The app crashes sometimes, needs fixing.', '2024-12-09 17:45:44', 'Pending'),
(20, 2, 'jane_smith', 'I love the new features in the latest update.', '2024-12-09 17:45:44', 'Pending'),
(23, 18, '', 'i love it', '2024-12-09 18:16:14', 'Pending'),
(24, 7, '', 'rtrtwtwe', '2024-12-09 18:16:33', 'Pending'),
(25, 7, 'daniel_miller', 'rtrtwtwe', '2024-12-09 18:18:54', 'Pending'),
(26, 7, 'daniel_miller', 'lala', '2024-12-09 18:20:31', 'Pending'),
(27, 18, 'queanh', 'hihihaha', '2024-12-09 18:20:48', 'Pending'),
(28, 18, 'queanh', 'tao thấy web xấu quá', '2024-12-11 18:06:11', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `id` int(11) NOT NULL,
  `moduleName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `moduleName`) VALUES
(1, 'Mathematics Basic'),
(2, 'Introduction to Physics'),
(3, 'Advanced Chemistry'),
(4, 'Computer Science 101'),
(5, 'World History'),
(6, 'Biology Fundamentals'),
(11, 'math is good'),
(12, 'àewrtwetet'),
(13, 'physic is best'),
(14, 'hahaa'),
(15, 'math and physic'),
(16, 'english');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `post` varchar(255) NOT NULL,
  `postdate` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `moduleid` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `post`, `postdate`, `userid`, `moduleid`, `image`) VALUES
(6, '        Math quiz preparation tip', '2024-11-8', 4, 16, NULL),
(7, '        Biology lab session rescheduled', '2024-11-8', 3, 16, NULL),
(10, 'Chemistry practical guide', '2024-11-8', 3, 3, NULL),
(40, 'vcrtgb6yh', '2024-12-07', 2, 2, 'Math.jpg.jpg'),
(48, 'Math', '2024-12-12', 18, 16, 'Math.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'john_doe', 'john.doe@gmail.com', '123456'),
(2, 'jane_smith', 'jane.smith@gmail.com', '123456'),
(3, 'michael_brown', 'michael.brown@gmail.com', '123456'),
(4, 'emily_white', 'emily.whbrow@gmail.com', '123456'),
(5, 'william_jones', 'william.jones@gmail.com', '123456'),
(6, 'olivia_davis', 'olivia.davis@gmail.com', '123456'),
(7, 'daniel_miller', 'daniel.miller@gmail.com', '123456'),
(18, 'queanh', 'queanh@gmail.com', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_feedback` (`user_id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_ibfk_1` (`userid`),
  ADD KEY `moduleid` (`moduleid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_user_feedback` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_ibfk_2` FOREIGN KEY (`moduleid`) REFERENCES `module` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
